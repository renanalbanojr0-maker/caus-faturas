const { app, BrowserWindow, ipcMain } = require('electron');

// Aceita certificado autoassinado do VPS
app.commandLine.appendSwitch('ignore-certificate-errors');
const { autoUpdater } = require('electron-updater');
const path = require('path');
const fs = require('fs');
const os = require('os');
const express = require('express');
const http = require('http');
const https = require('https');
const { Server } = require('socket.io');
const { MongoClient } = require('mongodb');
const blindagem = require('./blindagem');

/* ── AUTO-UPDATER ────────────────────────────────────────────── */
autoUpdater.autoDownload = true;
autoUpdater.autoInstallOnAppQuit = false;

// feedURL vem do package.json (GitHub Releases)

autoUpdater.on('update-available', (info) => {
  console.log('[Update] Nova versão disponível:', info.version);
  // Mostra dialog nativo informando que está baixando
  if(win){
    const { dialog } = require('electron');
    dialog.showMessageBox(win, {
      type: 'info',
      title: 'Atualização Disponível',
      message: `Nova versão ${info.version} encontrada!`,
      detail: 'O download começou automaticamente. O programa será reiniciado quando terminar.',
      buttons: ['OK'],
      noLink: true
    });
  }
});

autoUpdater.on('download-progress', (progress) => {
  const pct = Math.round(progress.percent);
  console.log('[Update] Baixando:', pct+'%');
});

autoUpdater.on('update-downloaded', () => {
  console.log('[Update] Baixada — instalando...');
  if(win){
    const { dialog } = require('electron');
    dialog.showMessageBox(win, {
      type: 'info',
      title: 'Atualização Pronta',
      message: '✅ Download concluído!',
      detail: 'O programa será reiniciado agora para instalar a atualização.',
      buttons: ['Reiniciar agora'],
      noLink: true
    }).then(() => {
      autoUpdater.quitAndInstall(false, true);
    });
  } else {
    autoUpdater.quitAndInstall(false, true);
  }
});

autoUpdater.on('error', (err) => {
  console.log('[Update] Erro:', err.message);
});

autoUpdater.on('update-not-available', () => {
  console.log('[Update] Versão mais recente.');
});

function mostrarJanelaUpdate(versao){
  if(winUpdate) return;
  winUpdate = new BrowserWindow({
    width:440, height:300,
    resizable:false, minimizable:false, maximizable:false,
    closable:false, alwaysOnTop:true, frame:false,
    backgroundColor:'#181818',
    webPreferences:{ nodeIntegration:true, contextIsolation:false }
  });
  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8">
  <style>
    *{margin:0;padding:0;box-sizing:border-box;}
    body{background:#181818;color:#fff;font-family:'Segoe UI',sans-serif;
      display:flex;flex-direction:column;align-items:center;justify-content:center;
      height:100vh;gap:16px;padding:32px;text-align:center;}
    .icon{font-size:48px;}
    h2{font-size:18px;font-weight:700;}
    p{font-size:13px;color:#aaa;}
    .wrap{width:100%;height:8px;background:#333;border-radius:99px;overflow:hidden;}
    .bar{height:100%;width:0%;background:#c8f060;border-radius:99px;transition:width .3s;}
    .pct{font-size:13px;color:#c8f060;font-weight:700;}
    small{color:#555;font-size:11px;}
  </style></head><body>
  <div class="icon">🔄</div>
  <h2 id="t">Atualização ${versao}</h2>
  <p id="m">Baixando nova versão, aguarde...</p>
  <div class="wrap"><div class="bar" id="b"></div></div>
  <div class="pct" id="p">0%</div>
  <small>O programa será reiniciado automaticamente.</small>
  <script>
    const {ipcRenderer}=require('electron');
    ipcRenderer.on('update-progresso',(e,v)=>{
      document.getElementById('b').style.width=v+'%';
      document.getElementById('p').textContent=v+'%';
    });
    ipcRenderer.on('update-pronto',()=>{
      document.getElementById('t').textContent='✅ Concluído!';
      document.getElementById('m').textContent='Reiniciando...';
      document.getElementById('b').style.width='100%';
      document.getElementById('p').textContent='100%';
    });
  </script></body></html>`;
  winUpdate.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(html));
}

let win;
let winCalc = null;
let winUpdate = null;
let dados = {};
let db = null; // conexão MongoDB
let io = null; // Socket.io global para usar no IPC

const INPUTS_POR_PAGINA = 70;
const MONGO_URI = 'mongodb+srv://renanalbanojr0_db_user:C6HBx39A4MkRBTfl@cluster0.h4o2rnn.mongodb.net/?appName=Cluster0';
const DB_NAME   = 'faturas';
const COL_NAME  = 'dados';

/* ── CAMINHOS ────────────────────────────────────────────────── */
// Tudo em Documentos\Caus Faturas\ — acessível e organizado
const baseDir    = path.join(os.homedir(), 'Documents', 'Caus Faturas');
const saveFile   = path.join(baseDir, 'dados.json');
const backupDir  = path.join(baseDir, 'FaturasBackup');
const faturasDir = path.join(baseDir, 'FaturasPDF');
const precDir    = path.join(baseDir, 'PrecificacaoNFs');

// ── BLINDAGEM (Dia 1): triple write + snapshots + journal ──
const backupFile     = path.join(baseDir, 'dados.backup.json');
const emergenciaDir  = path.join(app.getPath('userData'), 'emergencia');
const emergenciaFile = path.join(emergenciaDir, 'dados.emergencia.json');
const snapshotsDir   = path.join(baseDir, 'snapshots');
const journalFile    = path.join(baseDir, 'journal.log');

// Garante que todas as pastas existem ao iniciar
[baseDir, backupDir, faturasDir, precDir, emergenciaDir, snapshotsDir].forEach(p => {
  if(!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
});

// Inicializa módulo de blindagem
blindagem.inicializar({
  saveFile,
  backupFile,
  emergenciaFile,
  snapshotsDir,
  journalFile,
});

/* ── MONGODB ─────────────────────────────────────────────────── */
async function conectarMongo() {
  try {
    const client = new MongoClient(MONGO_URI);
    await client.connect();
    db = client.db(DB_NAME).collection(COL_NAME);
    console.log('✓ MongoDB conectado!');
  } catch(e) {
    console.warn('⚠ MongoDB offline — usando dados locais:', e.message);
    db = null;
  }
}

async function carregarDoMongo() {
  if(!db) return null;
  try {
    const doc = await db.findOne({ _id: 'principal' });
    if(doc) { delete doc._id; return doc; }
    return null;
  } catch(e) {
    console.warn('Erro ao carregar do MongoDB:', e.message);
    return null;
  }
}

async function salvarNoMongo(payload) {
  if(!db) return;
  try {
    await db.replaceOne({ _id: 'principal' }, { _id: 'principal', ...payload }, { upsert: true });
  } catch(e) {
    console.warn('Erro ao salvar no MongoDB:', e.message);
  }
}

/* ── BACKUP DIÁRIO ───────────────────────────────────────────── */
function timestampAgora() {
  const d = new Date();
  const data = `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const hora = `${String(d.getHours()).padStart(2,'0')}h${String(d.getMinutes()).padStart(2,'0')}`;
  return `${data}_${hora}`;
}

function fazerBackup(motivo) {
  try {
    if (!fs.existsSync(saveFile)) return;
    if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
    const nomeArquivo  = `dados_${timestampAgora()}_${motivo}.json`;
    const arquivoBackup = path.join(backupDir, nomeArquivo);
    fs.copyFileSync(saveFile, arquivoBackup);
    console.log(`Backup criado: ${nomeArquivo}`);
    const arquivos = fs.readdirSync(backupDir)
      .filter(f => f.startsWith('dados_') && f.endsWith('.json'))
      .sort();
    if (arquivos.length > 60) {
      arquivos.slice(0, arquivos.length - 60)
        .forEach(f => fs.unlinkSync(path.join(backupDir, f)));
    }
  } catch (err) {
    console.error('Erro ao fazer backup:', err);
  }
}

// Baixa dados atualizados do VPS e faz backup local
async function backupDoVPS(motivo = 'auto') {
  try {
    const https = require('https');
    const url = require('url');
    const parsed = url.parse('https://appcaus.com.br/dados-atual');
    const data = await new Promise((resolve, reject) => {
      const req = https.get({
        hostname: parsed.hostname,
        port: parsed.port || 443,
        path: parsed.path,
        timeout: 15000,
        headers: { 'User-Agent': 'CausFaturas-Backup' }
      }, res => {
        if (res.statusCode !== 200) {
          reject(new Error(`HTTP ${res.statusCode}`));
          return;
        }
        let body = '';
        res.on('data', c => body += c);
        res.on('end', () => resolve(body));
      });
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
    });
    // Valida JSON
    const dadosVps = JSON.parse(data); // lança erro se não for JSON válido

    // 1. Salva backup datado em FaturasBackup (histórico)
    if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir, { recursive: true });
    const nomeArquivo = `dados_${timestampAgora()}_${motivo}.json`;
    fs.writeFileSync(path.join(backupDir, nomeArquivo), data, 'utf8');
    console.log(`[Backup VPS] Criado: ${nomeArquivo}`);

    // 2. Atualiza dados.json local + cópias do triple write
    //    Isso mantém saveFile populado mesmo se o socket não receber update-data
    //    (caso típico no PC de casa que abre raramente)
    if (dadosValidos(dadosVps)) {
      blindagem.tripleWrite(dadosVps).catch(err => {
        console.error('[Backup VPS] Triple write falhou:', err.message);
      });
    }

    // 3. Mantém só os 60 backups mais recentes
    const arquivos = fs.readdirSync(backupDir)
      .filter(f => f.startsWith('dados_') && f.endsWith('.json'))
      .sort();
    if (arquivos.length > 60) {
      arquivos.slice(0, arquivos.length - 60)
        .forEach(f => fs.unlinkSync(path.join(backupDir, f)));
    }
  } catch (err) {
    console.error('[Backup VPS] Erro:', err.message);
  }
}

/* ── CARREGAR DADOS ──────────────────────────────────────────── */
// Valida se os dados não estão corrompidos (páginas com tamanho muito anormal)
function dadosValidos(raw) {
  const arr = Array.isArray(raw) ? raw : (raw.dados || []);
  const corrompido = arr.length > 0 && arr.some(
    p => Array.isArray(p) && p.length > 0 && Math.abs(p.length - INPUTS_POR_PAGINA) > 10
  );
  return !corrompido;
}

function carregarDadosLocal() {
  // 1. Tenta pelas 3 cópias do triple write (principal → backup → emergência)
  const dadosBlindagem = blindagem.carregarDadosSeguro();
  if (dadosBlindagem && dadosValidos(dadosBlindagem)) return dadosBlindagem;

  // 2. Se todas as 3 falharem, tenta os backups antigos da pasta FaturasBackup
  if (fs.existsSync(backupDir)) {
    const backups = fs.readdirSync(backupDir)
      .filter(f => f.startsWith('dados_') && f.endsWith('.json'))
      .sort().reverse();
    for (const bk of backups) {
      try {
        const raw = JSON.parse(fs.readFileSync(path.join(backupDir, bk), 'utf8'));
        if (dadosValidos(raw)) {
          console.log(`[Blindagem] Recuperado de backup antigo: ${bk}`);
          blindagem.tripleWrite(raw).catch(e => console.error('Erro ao re-gravar:', e));
          return raw;
        }
      } catch { continue; }
    }
  }

  // 3. Se absolutamente tudo falhar, retorna vazio
  console.warn('[Blindagem] Nenhum backup recuperável — iniciando vazio.');
  return {};
}

/* ── PROXY TINY API (para calculadora de NFs) ────────────────── */
function tinyRequest(tinyPath, body, callback) {
  const formBody = Object.entries(body)
    .map(([k,v]) => encodeURIComponent(k)+'='+encodeURIComponent(v))
    .join('&');
  const opts = {
    hostname: 'api.tiny.com.br', port: 443,
    path: '/api2/' + tinyPath, method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': Buffer.byteLength(formBody)
    }
  };
  const req = https.request(opts, res => {
    let d = ''; res.on('data', c => d += c); res.on('end', () => callback(null, d));
  });
  req.on('error', err => callback(err, null));
  req.write(formBody); req.end();
}

/* ── DANFE: carrega biblioteca nfe-danfe-pdf ─────────────────── */
let gerarPDF = null;
(async () => {
  try {
    const lib = await import('nfe-danfe-pdf');
    gerarPDF = lib.gerarPDF || lib.default?.gerarPDF;
    console.log('✓ Biblioteca DANFE carregada');
  } catch(e) {
    console.warn('⚠ nfe-danfe-pdf não encontrado. Rode: npm install nfe-danfe-pdf');
  }
})();

function pdfkitToBuffer(doc) {
  const { PassThrough } = require('stream');
  return new Promise((resolve, reject) => {
    const pass = new PassThrough();
    const chunks = [];
    pass.on('data',  c => chunks.push(c));
    pass.on('end',   () => resolve(Buffer.concat(chunks)));
    pass.on('error', reject);
    doc.on('error',  e => { if (chunks.length > 0) resolve(Buffer.concat(chunks)); else reject(e); });
    doc.pipe(pass);
  });
}

function sendJSON(res, code, obj) {
  if (res.headersSent) return;
  res.writeHead(code, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify(obj));
}

/* ── CRIAR JANELA PRINCIPAL ──────────────────────────────────── */
const VPS_URL = 'https://appcaus.com.br';

async function createWindow() {
  // Limpa cache do Electron ao abrir - evita ter que dar Ctrl+Shift+R pra ver atualizações do VPS
  try {
    const { session } = require('electron');
    await session.defaultSession.clearCache();
    console.log('Cache do Electron limpo.');
  } catch(e) {
    console.warn('Não foi possível limpar cache:', e.message);
  }

  // Conecta MongoDB e carrega dados
  await conectarMongo();
  const mongoData = await carregarDoMongo();
  dados = mongoData || carregarDadosLocal();

  // Snapshot automático a cada 5 min (mantém 48h de histórico)
  blindagem.iniciarSnapshotAutomatico(5);
  blindagem.escreverJournal('app-start', {
    versao: app.getVersion(),
    mongoConectado: !!db,
    origem: mongoData ? 'mongo' : 'local',
  });

  // Backup inicial baixando do VPS + a cada 5 minutos
  backupDoVPS('abertura');
  setInterval(() => backupDoVPS('auto'), 5 * 60 * 1000);

  const expressApp = express();
  const server = http.createServer(expressApp);
  io = new Server(server);

  const publicPath = path.join(app.getAppPath(), 'public');

  expressApp.use(express.static(publicPath));
  expressApp.get('/', (req, res) => res.sendFile(path.join(publicPath, 'index.html')));

  // Rotas do histórico de precificação (MongoDB)
  expressApp.get('/historico-prec', async (req, res) => {
    try {
      if(!db) return res.json({ historico: [] });
      const doc = await db.findOne({ _id: 'historico_precificacao' });
      res.json({ historico: doc?.historico || [] });
    } catch(e) {
      console.error('[Histórico] Erro ao carregar:', e.message);
      res.json({ historico: [] });
    }
  });

  expressApp.post('/historico-prec', express.json({ limit: '5mb' }), async (req, res) => {
    try {
      if(!db) return res.json({ ok: false, erro: 'MongoDB não conectado' });
      const { historico } = req.body || {};
      await db.replaceOne(
        { _id: 'historico_precificacao' },
        { _id: 'historico_precificacao', historico: historico || [] },
        { upsert: true }
      );
      res.json({ ok: true });
    } catch(e) {
      console.error('[Histórico] Erro ao salvar:', e.message);
      res.json({ ok: false, erro: e.message });
    }
  });

  // Rota para salvar PDF das NFs de precificação
  expressApp.post('/salvar-pdf-nf', express.json({ limit: '20mb' }), (req, res) => {
    try {
      const { nome, pdf, isLocal } = req.body || {};
      if(!nome || !pdf) return res.json({ ok: false, erro: 'Dados incompletos' });
      const buffer = Buffer.from(pdf, 'base64');

      // Sempre salva na pasta PrecificacaoNFs do projeto
      fs.writeFileSync(path.join(precDir, nome), buffer);
      console.log(`[PDF NF] Salvo em PrecificacaoNFs: ${nome}`);

      // Se for acesso local (Electron), salva também nos Downloads
      let caminhoDownload = null;
      if(isLocal){
        const downloads = path.join(os.homedir(), 'Downloads');
        caminhoDownload = path.join(downloads, nome);
        fs.writeFileSync(caminhoDownload, buffer);
        console.log(`[PDF NF] Salvo nos Downloads: ${nome}`);
      }

      res.json({ ok: true, caminho: caminhoDownload || pasta });
    } catch(err) {
      console.error('[PDF NF] Erro:', err.message);
      res.json({ ok: false, erro: err.message });
    }
  });

  /* ── Rotas da Calculadora de NFs ── */
  const tinyRoutes = {
    listar_nf:  'notas.fiscais.pesquisa.php',
    detalhe_nf: 'nota.fiscal.obter.php',
  };

  expressApp.post('/tiny-api', express.json({ limit: '10mb' }), async (req, res) => {
    const { action, token, params } = req.body || {};
    if (!token && action !== 'danfe_from_xml') {
      return sendJSON(res, 400, { erro: 'Token obrigatório' });
    }

    // Gerar DANFE a partir de XML enviado pelo browser
    if (action === 'danfe_from_xml') {
      if (!gerarPDF) return sendJSON(res, 503, { erro: 'Rode: npm install nfe-danfe-pdf' });
      const xml = (params?.xml || '').trim();
      if (!xml) return sendJSON(res, 400, { erro: 'XML não enviado' });
      console.log(`[DANFE] gerando PDF (${xml.length} chars)...`);
      try {
        let xmlFinal = xml;
        if (xml.includes('<NFe') && !xml.includes('<nfeProc')) {
          xmlFinal = `<nfeProc versao="4.00" xmlns="http://www.portalfiscal.inf.br/nfe">${xml}</nfeProc>`;
        }
        const doc = await gerarPDF(xmlFinal, { cancelada: false });
        const buf = await pdfkitToBuffer(doc);
        console.log(`[DANFE] OK — ${buf.length} bytes`);
        return sendJSON(res, 200, { pdf: buf.toString('base64') });
      } catch(e) {
        console.error('[DANFE] Erro:', e.message);
        return sendJSON(res, 500, { erro: 'Erro ao gerar DANFE: ' + e.message });
      }
    }

    // Rotas normais do Tiny
    const routePath = tinyRoutes[action];
    if (!routePath) return sendJSON(res, 400, { erro: 'Ação desconhecida: ' + action });
    const tinyParams = { token, formato: 'json', ...(params || {}) };
    console.log(`[Tiny] ${action} → /api2/${routePath}`);
    tinyRequest(routePath, tinyParams, (err, rawData) => {
      if (err) return sendJSON(res, 500, { erro: err.message });
      try {
        const parsed = JSON.parse(rawData);
        console.log(`  status: ${parsed?.retorno?.status}`);
        sendJSON(res, 200, parsed);
      } catch(e) {
        sendJSON(res, 500, { erro: 'Resposta inválida: ' + rawData.substring(0, 200) });
      }
    });
  });

  /* ── Socket.io ── */
  io.on('connection', (socket) => {
    socket.emit('load-data', dados);
    blindagem.escreverJournal('socket-connect', { socketId: socket.id });

    socket.on('update-data', (payload) => {
      dados = payload;
      // Triple write (local + backup + emergência) — escrita atômica
      blindagem.tripleWrite(dados).catch(err => {
        console.error('[Blindagem] Triple write falhou:', err.message);
      });
      blindagem.escreverJournal('update-data', {
        socketId: socket.id,
        qtdFaturas: Array.isArray(dados?.dados) ? dados.dados.length : 0,
      });
      // Salva no MongoDB
      salvarNoMongo(dados);
      io.emit('load-data', dados);
    });

    socket.on('reset-all', () => {
      fazerBackup('antes-do-reset');
      blindagem.tirarSnapshot(); // snapshot de segurança antes de zerar
      blindagem.escreverJournal('reset-all', { socketId: socket.id });
      dados = {};
      blindagem.tripleWrite(dados).catch(err => {
        console.error('[Blindagem] Triple write (reset) falhou:', err.message);
      });
      salvarNoMongo(dados);
      io.emit('reset-all');
    });

    // Recebe PDF da calculadora e salva na pasta PrecificacaoNFs
    socket.on('salvar-pdf-nf', ({ nome, pdf }) => {
      try {
        const pasta = path.join(process.cwd(), 'PrecificacaoNFs');
        if (!fs.existsSync(pasta)) fs.mkdirSync(pasta, { recursive: true });
        const arquivo = path.join(pasta, nome);
        const buffer = Buffer.from(pdf, 'base64');
        fs.writeFileSync(arquivo, buffer);
        console.log(`[PDF NF] Salvo: ${nome}`);
        socket.emit('pdf-nf-salvo', { ok: true });
      } catch(err) {
        console.error('[PDF NF] Erro ao salvar:', err.message);
        socket.emit('pdf-nf-salvo', { ok: false, erro: err.message });
      }
    });

    // Recebe imagem da fatura e salva na pasta FaturasPDF/DD-MM-YYYY
    socket.on('salvar-imagem', ({ numero, imgBase64 }) => {
      try {
        const hoje = new Date();
        const dataStr = `${String(hoje.getDate()).padStart(2,'0')}-${String(hoje.getMonth()+1).padStart(2,'0')}-${hoje.getFullYear()}`;
        const pasta = path.join(faturasDir, dataStr);
        if (!fs.existsSync(pasta)) fs.mkdirSync(pasta, { recursive: true });
        const arquivo = path.join(pasta, `FAT ${numero}.jpg`);
        const buffer = Buffer.from(imgBase64, 'base64');
        fs.writeFileSync(arquivo, buffer);
        console.log(`[Imagem] Salva: FaturasPDF/${dataStr}/FAT ${numero}.jpg`);
        // Envia de volta para quem enviou salvar localmente
        socket.emit('imagem-salva', { numero, ok: true, imgBase64, dataStr });
        // Propaga para todos os outros clientes conectados salvarem também
        socket.broadcast.emit('salvar-imagem-copia', { numero, imgBase64, dataStr });
      } catch(err) {
        console.error('[Imagem] Erro ao salvar:', err.message);
        socket.emit('imagem-salva', { numero, ok: false, erro: err.message });
      }
    });
  });

  // Rota ping para identificação na rede (com CORS para PC2 detectar)
  expressApp.get('/ping', (req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.json({ servidor: 'caus-faturas', ok: true });
  });

  server.listen(3000, '0.0.0.0', () => {
    win = new BrowserWindow({
      width: 1400, height: 900,
      show: false, // não mostra até carregar
      webPreferences: { nodeIntegration: true, contextIsolation: false }
    });
    // Mostra janela só quando terminar de carregar — sem tela branca
    win.once('ready-to-show', () => win.show());
    win.loadURL(VPS_URL);

    // Verifica atualização 3 segundos após abrir
    setTimeout(() => {
      autoUpdater.checkForUpdates()
        .then(r => console.log('[Update] Resultado:', JSON.stringify(r?.updateInfo)))
        .catch(e => console.log('[Update] Erro:', e.message));
    }, 3000);
  });

  /* ── IPC: retorna versão do app ── */
  ipcMain.handle('get-version', () => app.getVersion());

  /* ── IPC: salva cópia local da imagem no PC2 ── */
  ipcMain.handle('salvar-imagem-local', async (event, { numero, imgBase64 }) => {
    try {
      const hoje = new Date();
      const dataStr = `${String(hoje.getDate()).padStart(2,'0')}-${String(hoje.getMonth()+1).padStart(2,'0')}-${hoje.getFullYear()}`;
      const pasta = path.join(faturasDir, dataStr);
      if (!fs.existsSync(pasta)) fs.mkdirSync(pasta, { recursive: true });
      const arquivo = path.join(pasta, `FAT ${numero}.jpg`);
      const buffer = Buffer.from(imgBase64, 'base64');
      fs.writeFileSync(arquivo, buffer);
      console.log(`[Imagem PC2] Cópia local salva: FAT ${numero}.jpg`);
      return { ok: true };
    } catch(err) {
      console.error('[Imagem PC2] Erro:', err.message);
      return { ok: false };
    }
  });

  /* ── IPC: verificar atualização manualmente ── */
  ipcMain.on('verificar-update-manual', async (event) => {
    try {
      console.log('[Update] Verificação manual iniciada...');
      const result = await autoUpdater.checkForUpdates();
      if(result && result.updateInfo){
        const v = result.updateInfo.version;
        event.reply('update-resultado', `Versão disponível: ${v}
Baixando automaticamente...`);
      } else {
        event.reply('update-resultado', 'Programa já está na versão mais recente!');
      }
    } catch(e) {
      console.error('[Update] Erro:', e.message);
      event.reply('update-resultado', 'Erro ao verificar: ' + e.message);
    }
  });

  /* ── IPC: salvar PDF da calculadora de NFs ── */
  ipcMain.handle('salvar-pdf-nf-calc', async (event, { nome, pdf }) => {
    try {
      // 1. Salva nos Downloads do PC local
      const downloads = path.join(os.homedir(), 'Downloads');
      const arquivoLocal = path.join(downloads, nome);
      const buffer = Buffer.from(pdf, 'base64');
      fs.writeFileSync(arquivoLocal, buffer);
      console.log(`[PDF NF] Salvo nos Downloads: ${nome}`);

      // 2. Salva na pasta PrecificacaoNFs do projeto (PC1)
      const pastaProj = path.join(process.cwd(), 'PrecificacaoNFs');
      if (!fs.existsSync(pastaProj)) fs.mkdirSync(pastaProj, { recursive: true });
      const arquivoProj = path.join(pastaProj, nome);
      fs.writeFileSync(arquivoProj, buffer);
      console.log(`[PDF NF] Cópia salva em PrecificacaoNFs: ${nome}`);

      // 3. Se houver outros PCs conectados via socket, envia para eles também
      io.emit('pdf-nf-recebido', { nome, pdf });

      return { ok: true, caminho: arquivoLocal };
    } catch(err) {
      console.error('[PDF NF] Erro:', err.message);
      return { ok: false, erro: err.message };
    }
  });

  /* ── IPC: abrir janela calculadora ── */
  ipcMain.on('abrir-calculadora', () => {
    if (winCalc && !winCalc.isDestroyed()) {
      winCalc.focus();
      return;
    }
    winCalc = new BrowserWindow({
      width: 1300, height: 850,
      title: 'Calculadora de NFs',
      webPreferences: { nodeIntegration: false, contextIsolation: true, devTools: true }
    });
    winCalc.loadURL(VPS_URL + '/calculadora-nf.html');
    winCalc.on('closed', () => { winCalc = null; });
  });

  /* salvar-pdf removido — agora usa imagem via socket */
}

app.whenReady().then(() => createWindow().catch(console.error));

app.on('before-quit', () => {
  blindagem.escreverJournal('app-quit', { motivo: 'fechamento' });
  blindagem.pararSnapshotAutomatico();
  blindagem.tirarSnapshot(); // snapshot final antes de fechar
  backupDoVPS('fechamento');
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
