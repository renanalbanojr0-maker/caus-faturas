/* ═══════════════════════════════════════════════════════════════
   CAUS Faturas — Backup Backblaze B2 (Dia 4)
   ═══════════════════════════════════════════════════════════════
   Backup redundante no Backblaze B2, independente do Google Drive.
   Roda diariamente às 4h (1h depois do backup do Drive pra não sobrecarregar).

   O QUE ENVIA:
     1. dados.json do VPS
     2. Pastas diárias do FaturasPDF (zip por dia)

   ESTRUTURA NO BUCKET:
     caus-faturas-backup/
     ├── dados/
     │   └── backup_2026-04-24_04h00.json
     ├── faturas/
     │   └── faturas_24-04-2026.zip
     └── ...

   RETENÇÃO:
     - dados.json: mantém últimos 90 dias (auto-limpa)
     - faturas zips: mantém últimos 180 dias (auto-limpa)
   ═══════════════════════════════════════════════════════════════ */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const B2 = require('backblaze-b2');

/* ── CONFIG ─────────────────────────────────────────────────── */
const CONFIG = {
  applicationKeyId: process.env.B2_KEY_ID     || '00580933ce8365d0000000002',
  applicationKey:   process.env.B2_APP_KEY    || 'K005rCKttfQNR8ne4ngmm0JbbUYTGM8',
  bucketId:         process.env.B2_BUCKET_ID  || '282059f3632cce0893d6051d',
  bucketName:       process.env.B2_BUCKET_NAME || 'caus-faturas-backup',
  // Retenção
  retencaoDadosDias:    90,
  retencaoFaturasDias:  180,
};

const DADOS_DIR   = '/var/www/caus-faturas/dados';
const DADOS_FILE  = path.join(DADOS_DIR, 'dados.json');
const FATURAS_DIR = path.join(DADOS_DIR, 'FaturasPDF');
const TMP_DIR     = '/tmp';

const b2 = new B2({
  applicationKeyId: CONFIG.applicationKeyId,
  applicationKey:   CONFIG.applicationKey,
});

/* ── HELPERS ────────────────────────────────────────────────── */
function log(msg)    { console.log(`[B2] ${msg}`); }
function logErr(msg) { console.error(`[B2] ❌ ${msg}`); }

async function autorizar() {
  await b2.authorize();
  log('Autorizado com sucesso.');
}

async function uploadArquivo(caminhoLocal, nomeNoBucket) {
  const tamanhoMB = (fs.statSync(caminhoLocal).size / 1024 / 1024).toFixed(2);
  log(`Enviando: ${nomeNoBucket} (${tamanhoMB} MB)...`);

  const dadosArquivo = fs.readFileSync(caminhoLocal);

  const getUrl = await b2.getUploadUrl({ bucketId: CONFIG.bucketId });

  await b2.uploadFile({
    uploadUrl: getUrl.data.uploadUrl,
    uploadAuthToken: getUrl.data.authorizationToken,
    fileName: nomeNoBucket,
    data: dadosArquivo,
    contentLength: dadosArquivo.length,
  });

  log(`✓ ${nomeNoBucket} enviado.`);
}

async function listarArquivos(prefixo) {
  const resp = await b2.listFileNames({
    bucketId: CONFIG.bucketId,
    prefix: prefixo,
    maxFileCount: 10000,
  });
  return resp.data.files.map(f => ({
    fileName: f.fileName,
    fileId: f.fileId,
    uploadTimestamp: f.uploadTimestamp,
  }));
}

async function apagarArquivo(fileName, fileId) {
  try {
    await b2.deleteFileVersion({ fileName, fileId });
    log(`🗑  Removido antigo: ${fileName}`);
  } catch (e) {
    logErr(`Falha ao remover ${fileName}: ${e.message}`);
  }
}

/* ── LIMPEZA POR IDADE ──────────────────────────────────────── */
async function limparAntigos(prefixo, diasRetencao) {
  const arquivos = await listarArquivos(prefixo);
  const limite = Date.now() - (diasRetencao * 24 * 60 * 60 * 1000);

  let removidos = 0;
  for (const arq of arquivos) {
    if (arq.uploadTimestamp < limite) {
      await apagarArquivo(arq.fileName, arq.fileId);
      removidos++;
    }
  }
  if (removidos > 0) {
    log(`${removidos} arquivo(s) antigo(s) removido(s) do prefixo "${prefixo}".`);
  }
}

/* ── VERIFICAR SE ARQUIVO JÁ EXISTE NO BUCKET ───────────────── */
async function arquivoExisteNoBucket(nomeNoBucket) {
  const arquivos = await listarArquivos(nomeNoBucket);
  return arquivos.some(a => a.fileName === nomeNoBucket);
}

/* ── LISTAR PASTAS DE FATURAS NO FORMATO DD-MM-AAAA ─────────── */
function listarPastasFaturas() {
  if (!fs.existsSync(FATURAS_DIR)) return [];
  return fs.readdirSync(FATURAS_DIR).filter(nome => {
    const caminho = path.join(FATURAS_DIR, nome);
    return fs.statSync(caminho).isDirectory() && /^\d{2}-\d{2}-\d{4}$/.test(nome);
  });
}

/* ═══════════════════════════════════════════════════════════════
   BACKUP PRINCIPAL
   ═══════════════════════════════════════════════════════════════ */
async function fazerBackup() {
  const inicio = Date.now();

  try {
    log('Iniciando backup pro Backblaze B2...');
    await autorizar();

    const agora = new Date();
    const dataISO = `${agora.getFullYear()}-${String(agora.getMonth()+1).padStart(2,'0')}-${String(agora.getDate()).padStart(2,'0')}`;
    const hora = `${String(agora.getHours()).padStart(2,'0')}h${String(agora.getMinutes()).padStart(2,'0')}`;

    // ═══════════════════════════════════════════════════
    // 1) BACKUP DO dados.json
    // ═══════════════════════════════════════════════════
    if (fs.existsSync(DADOS_FILE)) {
      const nomeJson = `dados/backup_${dataISO}_${hora}.json`;
      await uploadArquivo(DADOS_FILE, nomeJson);
    } else {
      log('⚠️  dados.json não encontrado, pulando.');
    }

    // ═══════════════════════════════════════════════════
    // 2) BACKUP DAS FATURAS (zips por dia)
    // ═══════════════════════════════════════════════════
    const pastasFaturas = listarPastasFaturas();
    log(`${pastasFaturas.length} pasta(s) de faturas encontradas.`);

    for (const pastaNome of pastasFaturas) {
      const pastaCaminho = path.join(FATURAS_DIR, pastaNome);
      const arquivos = fs.readdirSync(pastaCaminho);
      if (arquivos.length === 0) continue;

      const nomeZip = `faturas/faturas_${pastaNome}.zip`;

      // Se já existe no bucket, pula (cada dia sobe uma vez só)
      if (await arquivoExisteNoBucket(nomeZip)) {
        log(`⏭  ${nomeZip} já existe no B2, pulando.`);
        continue;
      }

      const zipPath = path.join(TMP_DIR, `b2_faturas_${pastaNome}.zip`);

      if (fs.existsSync(zipPath)) fs.unlinkSync(zipPath);

      log(`📦 Compactando ${pastaNome} (${arquivos.length} arquivo(s))...`);
      try {
        execSync(`cd "${FATURAS_DIR}" && zip -r -q "${zipPath}" "${pastaNome}"`);
        await uploadArquivo(zipPath, nomeZip);
        fs.unlinkSync(zipPath);
      } catch (e) {
        logErr(`Falha ao processar ${pastaNome}: ${e.message}`);
        if (fs.existsSync(zipPath)) {
          try { fs.unlinkSync(zipPath); } catch(_) {}
        }
      }
    }

    // ═══════════════════════════════════════════════════
    // 3) LIMPEZA DE ARQUIVOS ANTIGOS NO BUCKET
    // ═══════════════════════════════════════════════════
    log('Verificando arquivos antigos pra remover...');
    await limparAntigos('dados/',   CONFIG.retencaoDadosDias);
    await limparAntigos('faturas/', CONFIG.retencaoFaturasDias);

    const duracao = ((Date.now() - inicio) / 1000).toFixed(1);
    log(`✅ Backup Backblaze concluído em ${duracao}s.`);

  } catch (e) {
    logErr(`Erro geral: ${e.message}`);
    console.error(e.stack);
    process.exit(1);
  }
}

fazerBackup();
